'''Calculation KS statistic for a model.'''	
from .ks import summary, plot, perf

name = "pyks"	
__version__ = "1.1.5"
