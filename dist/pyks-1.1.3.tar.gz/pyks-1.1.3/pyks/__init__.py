'''Calculation KS statistic for a model.'''
from .ks import summary
from .ks2 import plot

name = "pyks"
__version__ = '1.1.3'
